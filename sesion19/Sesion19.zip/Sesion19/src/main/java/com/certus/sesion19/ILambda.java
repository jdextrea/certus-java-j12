/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.certus.sesion19;

/**
 *
 * @author jdextre
 */
@FunctionalInterface
public interface ILambda {
    //Mostrar mensaje
    void sumar(int n1,int n2);
}
