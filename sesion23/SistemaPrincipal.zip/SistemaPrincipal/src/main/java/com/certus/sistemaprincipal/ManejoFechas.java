/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certus.sistemaprincipal;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author jdextre
 */
public class ManejoFechas {
     public static void main(String[] args) { 
         //Mostrar la fecha Actual
         LocalDate fechaActual = LocalDate.now();
         System.out.println(fechaActual);
         
         //Cambiar la fecha
         LocalDate fechaPasada = LocalDate.of(2019,01,20);
         System.out.println(fechaPasada);
         
         //Validar si el año es bisiesto
         LocalDate bisiesto = LocalDate.of(2024,11,30);
         System.out.println(bisiesto.isLeapYear());
         
         //Parse
         DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
         String fechaNueva = "2021/10/23";
         LocalDate fecha = LocalDate.parse(fechaNueva, formatter);
         System.out.println(fecha);
         
         
         
     }
}
