/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certus.patronfacade;

public class Battery {

    public void on() {
        System.out.println("Battery on");
    }

    public void off() {
        System.out.println("Battery off");
    }
}
